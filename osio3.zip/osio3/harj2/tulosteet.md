### docker build -t python-kontti-demo .

```
DEPRECATED: The legacy builder is deprecated and will be removed in a future release.
            Install the buildx component to build images with BuildKit:
            https://docs.docker.com/go/buildx/

Sending build context to Docker daemon  4.096kB
Step 1/6 : FROM python:3.10-slim
3.10-slim: Pulling from library/python
0c8d55a45c0d: Pulling fs layer
690eaffcf0e9: Pulling fs layer
d0d1977db485: Pulling fs layer
63ebb7511fc1: Pulling fs layer
63ebb7511fc1: Waiting
690eaffcf0e9: Verifying Checksum
d0d1977db485: Verifying Checksum
d0d1977db485: Download complete
0c8d55a45c0d: Verifying Checksum
0c8d55a45c0d: Download complete
63ebb7511fc1: Verifying Checksum
63ebb7511fc1: Download complete
0c8d55a45c0d: Pull complete
690eaffcf0e9: Pull complete
d0d1977db485: Pull complete
63ebb7511fc1: Pull complete
Digest: sha256:e508a34e5491225a76fbb9e0f43ebde1f691c6a689d096d7510cf7fb17d4ba6f
Status: Downloaded newer image for python:3.10-slim
 ---> 988b1bc80158
Step 2/6 : WORKDIR /app
 ---> Running in 707d1a12d0cd
 ---> Removed intermediate container 707d1a12d0cd
 ---> a99b49d467c0
Step 3/6 : COPY requirements.txt .
 ---> 33c47b3a4088
Step 4/6 : RUN pip install -r requirements.txt
 ---> Running in b0519bd27f24
Collecting flask
  Downloading flask-3.1.3-py3-none-any.whl (103 kB)
     ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 103.4/103.4 kB 3.7 MB/s eta 0:00:00
Collecting blinker>=1.9.0
  Downloading blinker-1.9.0-py3-none-any.whl (8.5 kB)
Collecting itsdangerous>=2.2.0
  Downloading itsdangerous-2.2.0-py3-none-any.whl (16 kB)
Collecting werkzeug>=3.1.0
  Downloading werkzeug-3.1.6-py3-none-any.whl (225 kB)
     ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 225.2/225.2 kB 9.7 MB/s eta 0:00:00
Collecting click>=8.1.3
  Downloading click-8.3.1-py3-none-any.whl (108 kB)
     ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 108.3/108.3 kB 53.6 MB/s eta 0:00:00
Collecting markupsafe>=2.1.1
  Downloading markupsafe-3.0.3-cp310-cp310-manylinux2014_x86_64.manylinux_2_17_x86_64.manylinux_2_28_x86_64.whl (20 kB)
Collecting jinja2>=3.1.2
  Downloading jinja2-3.1.6-py3-none-any.whl (134 kB)
     ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 134.9/134.9 kB 48.4 MB/s eta 0:00:00
Installing collected packages: markupsafe, itsdangerous, click, blinker, werkzeug, jinja2, flask
Successfully installed blinker-1.9.0 click-8.3.1 flask-3.1.3 itsdangerous-2.2.0 jinja2-3.1.6 markupsafe-3.0.3 werkzeug-3.1.6
WARNING: Running pip as the 'root' user can result in broken permissions and conflicting behaviour with the system package manager. It is recommended to use a virtual environment instead: https://pip.pypa.io/warnings/venv

[notice] A new release of pip is available: 23.0.1 -> 26.0.1
[notice] To update, run: pip install --upgrade pip
 ---> Removed intermediate container b0519bd27f24
 ---> 35085e06da05
Step 5/6 : COPY . .
 ---> f0aa7639aaa8
Step 6/6 : CMD ["python", "app.py"]
 ---> Running in ff8b7ef99be2
 ---> Removed intermediate container ff8b7ef99be2
 ---> 2850269f7355
Successfully built 2850269f7355
Successfully tagged python-kontti-demo:latest
```

### docker run -d -p 5000:5000 --name kontti-python python-kontti-demo

```
5fa88c80e6c7c09063a153e65a27c252be130c661b51a36acc5d33e58c74f42e
```
